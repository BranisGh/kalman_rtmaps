import numpy as np
from aimotive.recording import Recording, SensorType
import pymap3d as pm
from unscented_kalman_filter import UKF_gen
from scipy.spatial.transform import Rotation as Rot
import json



def retrieve_sequence_data(record_dir):
    
    rec = Recording(path=record_dir,
                include_sensors_by_type=[SensorType.GPS, SensorType.DBW],
                fail_on_sensorconfig_missing=False)
 
    
    try:
        ublox = rec.get_ubloxgps(label="ublox_gps")
    except:
        ublox = rec.get_ubloxgps(label="ublox")
    
    gps_values = ublox.get_gps_datas().values()

    rec.get_dbw().init()
    dbw = rec.get_dbw().dbw_reader

    N_gps = len(gps_values)

    t_gps = np.zeros(N_gps)
    t_gps_device = np.zeros(N_gps) # for timestampHost correction
    lat_gps = np.zeros(N_gps)
    lon_gps = np.zeros(N_gps)
    alt_gps = np.zeros(N_gps)
    yr_gps = np.zeros(N_gps)

    for n, v in enumerate(gps_values):
        t_gps[n] = (v.timestampHost).total_seconds()
        t_gps_device[n] = (v.timestampDevice)*1e-6  # for timestampHost correction
        lat_gps[n] = v.gps.latlon.x
        lon_gps[n] = v.gps.latlon.y
        alt_gps[n] = v.gps.alt_m
    
    t_gps = t_gps_device - (t_gps_device[-1] - t_gps[-1]) # timestampHost correction
    t_gps_start = t_gps[0]
    t_gps_end = t_gps[-1]
            
    N_dbw = dbw.getEntryCount()
    t_dbw_start = dbw.getEntryTimestamp(0).total_seconds()
    t_dbw_end = dbw.getEntryTimestamp(N_dbw-1).total_seconds()


    n_dbw_gps_start_guess = int((N_dbw-1)*(t_gps_start-t_dbw_start)/(t_dbw_end -t_dbw_start))
    n_dbw_gps_end_guess = int((N_dbw-1)*(t_gps_end-t_dbw_start)/(t_dbw_end -t_dbw_start))
    t_dbw_gps_start_guess = dbw.getEntryTimestamp(n_dbw_gps_start_guess).total_seconds()
    t_dbw_gps_end_guess = dbw.getEntryTimestamp(n_dbw_gps_end_guess).total_seconds()

    n_dbw_gps_start = n_dbw_gps_start_guess
    t_dbw_gps_start = t_dbw_gps_start_guess
    n_dbw_gps_end = n_dbw_gps_end_guess
    t_dbw_gps_end = t_dbw_gps_end_guess

    if t_dbw_gps_start_guess <= t_gps_start:
        while ((t_gps_start - t_dbw_gps_start) > 0.01):
            n_dbw_gps_start +=1
            t_dbw_gps_start = dbw.getEntryTimestamp(n_dbw_gps_start).total_seconds()        
    else: 
        while ((t_gps_start - t_dbw_gps_start) < 0):
            n_dbw_gps_start -=1
            t_dbw_gps_start = dbw.getEntryTimestamp(n_dbw_gps_start).total_seconds()


    if t_dbw_gps_end_guess <= t_gps_end:
        while ((t_gps_end - t_dbw_gps_end) > 0):
            n_dbw_gps_end +=1
            t_dbw_gps_end = dbw.getEntryTimestamp(n_dbw_gps_end).total_seconds()       
    else:   
        while ((t_gps_end - t_dbw_gps_end) < -0.01):
            n_dbw_gps_end -=1
            t_dbw_gps_end = dbw.getEntryTimestamp(n_dbw_gps_end).total_seconds()

    N_dbw_seq = n_dbw_gps_end - n_dbw_gps_start + 1 
    t_dbw_seq = np.zeros(N_dbw_seq)
    yr_dbw_seq = np.zeros(N_dbw_seq)
    v_rl_dbw_seq = np.zeros(N_dbw_seq)
    v_rr_dbw_seq = np.zeros(N_dbw_seq)
    
    for n in range(n_dbw_gps_start, n_dbw_gps_end+1):
        t_dbw_seq[n-n_dbw_gps_start] = dbw.getEntryTimestamp(n).total_seconds()
        yr_dbw_seq[n-n_dbw_gps_start] = dbw.getYawRate(n).value()
        v_rl_dbw_seq[n-n_dbw_gps_start] = dbw.getWheelSpeeds(n).rearLeft.value()
        v_rr_dbw_seq[n-n_dbw_gps_start] = dbw.getWheelSpeeds(n).rearRight.value()
    
    gps_data = {"time":t_gps, "lat":lat_gps, "lon":lon_gps, "alt":alt_gps}
    veh_data = {"time_v":t_dbw_seq, "v_rl":v_rl_dbw_seq, "v_rr":v_rr_dbw_seq, "time_yr":t_dbw_seq, "yr":yr_dbw_seq}
    
    
    return gps_data, veh_data


def preprocess_data(gps_data, veh_data, dt):
    
    t_lat_lon_alt = gps_data["time"]
    lat = gps_data["lat"]
    lon = gps_data["lon"]
    alt = gps_data["alt"]
    
    t_v = veh_data["time_v"]
    v = (veh_data["v_rl"] + veh_data["v_rr"])/2
    t_yr = veh_data["time_yr"]
    yr = veh_data["yr"]
    
    # remove duplicate data
    t_lat_lon_alt, index = np.unique(t_lat_lon_alt, return_index = True)
    lat = lat[index]
    lon = lon[index]
    if np.size(alt) > 0:
        alt = alt[index]
        
    t_v, index = np.unique(t_v, return_index = True)
    v = v[index]
    
    t_yr, index = np.unique(t_yr, return_index = True)
    yr = yr[index] + 0*0.008 # bias correction for Cobra vehicle
    
    # lat,long,alt -> xm,ym,zm
    xm,ym,zm = pm.geodetic2enu(lat, lon, alt, lat[0], lon[0], alt[0])
    # xm,ym -> y_meas_raw
    y_meas_raw = np.vstack((xm,ym)).reshape(1,2,-1).T
    
    # resample data at dt steptime
    t_min = min(t_lat_lon_alt[0], t_v[0], t_yr[0])
    t_max = max(t_lat_lon_alt[-1], t_v[-1], t_yr[-1])
    t_sync = np.arange(t_min, t_max + dt, dt)
    Nt_sync = len(t_sync)
    
    # intialize measurement and control data 
    y_meas = np.full((Nt_sync,2,1), np.nan) 
    u = np.zeros((Nt_sync, 2,1))

    # fill measurement and control data 
    past_meas_index = []
    for k, tk in enumerate(t_sync):
            
        # fill measurement data
        prev_meas_index = np.where(tk >= t_lat_lon_alt)[0]
        if np.size(prev_meas_index):
            if prev_meas_index[-1] not in past_meas_index:
                y_meas[k] = y_meas_raw[prev_meas_index[-1]]
                past_meas_index.append(prev_meas_index[-1])
                
        # fill control data (v and yr)
        prev_v_index = np.where(tk >= t_v)[0]
        if np.size(prev_v_index):
            u[k,0,0] = v[prev_v_index[-1]]
        else:
            u[k,0,0] = v[0]
            
        prev_yr_index = np.where(tk >= t_yr)[0]
        if np.size(prev_yr_index):
            u[k,1,0] = yr[prev_yr_index[-1]]
        else:
            u[k,1,0] = yr[0]
            
    return t_sync, y_meas, u
         
               
def forward_ukf(ukf, x0, Px0, u, y):
    
    K = len(u)
    x_tab = np.zeros((K,3,1))
    x_tab[0] = x0
    Px_tab = np.zeros((K,3,3))
    Px_tab[0] = Px0
    x = x0
    Px = Px0
    for k in range(1,K):

        if u[k-1,0,0] > 0:
            x, Px = ukf.time_update_ukf(x, Px, u[k-1])
            #x = fx(x,u[k-1],dt)

        if ~np.isnan(y[k,0,0]):
            x, Px = ukf.measurement_update_ukf(x, Px, y[k])
   
        x_tab[k] = x
        Px_tab[k] = Px
    
    return x_tab, Px_tab

def backward_ukf(ukf, xf, Pxf, u, y):
    
    K = len(u)
    x_tab = np.zeros((K,3,1))
    x_tab[K-1] = xf
    Px_tab = np.zeros((K,3,3))
    Px_tab[K-1] = Pxf
    x = xf
    Px = Pxf
    for k in range(K-2,-1,-1):
    
        if u[k+1,0,0] > 0:
            x, Px = ukf.time_update_ukf(x, Px, u[k+1])

        if ~np.isnan(y[k,0,0]):
            x, Px = ukf.measurement_update_ukf(x, Px, y[k])
   
        x_tab[k] = x
        Px_tab[k] = Px
    
    return x_tab, Px_tab

def backward_smoothing_ukf(ukf, x_tab, Px_tab, u_tab):
    
    K = len(x_tab)
    x_rts_tab = np.zeros_like(x_tab)
    x_rts_tab[-1] = x_tab[-1]
    Px_rts_tab = np.zeros_like(Px_tab)
    Px_rts_tab[-1] = Px_tab[-1]
    x_rts = x_tab[-1]
    Px_rts = Px_tab[-1]
    kmin = np.where(Px_tab[:,0,0] > 0)[0][0]
    for k in range(K-2,-1,-1):
        
    # sigma points generation
        Sx_l = np.linalg.cholesky(Px_tab[k])
        Xx = ukf.generate_sigma_points(x_tab[k], Sx_l)
        # sigma points propagation through process
        Xx_p = ukf.process(Xx, u_tab[k])
        # compute predicted mean and covariance
        x_p = ukf.mean_x(Xx_p, ukf.w)
        Xx_minus_x_p = ukf.subtract_x(Xx_p, x_p)
        Px_p = Xx_minus_x_p@ukf.Wc@Xx_minus_x_p.T + ukf.Q
        
        Xx_minus_x = ukf.subtract_x(Xx, x_tab[k])
        Dxxp =  Xx_minus_x@ukf.Wc@Xx_minus_x_p.T
        
        G = Dxxp@np.linalg.inv(Px_p)
        x_rts = x_tab[k] + G@ukf.subtract_x(x_rts, x_p)
        Px_rts = Px_tab[k] + G@(Px_rts - Px_p)@G.T
    
        x_rts_tab[k] = x_rts
        Px_rts_tab[k] = Px_rts
    
    return x_rts_tab, Px_rts_tab

def normalize_angle(x):
    x = x % (2 * np.pi)    # force in range [0, 2 pi)
    x[x > np.pi] -= 2 * np.pi  # move to [-pi, pi)
    return x

def add_x(x1, x2):
    x = x1 + x2
    x[2] = normalize_angle(x[2])
    return x

def subtract_x(x1, x2):
    x = x1 - x2
    x[2] = normalize_angle(x[2])
    return x
      
def fx(x, u, dt):

    x[0] += dt*u[0]*np.cos(x[2] + dt*u[1]/2)
    x[1] += dt*u[0]*np.sin(x[2] + dt*u[1]/2)
    x[2] = normalize_angle(x[2] + dt*u[1])
    return x

def mean_x(X, w):
    x = np.zeros((X.shape[0], 1))
    x[0:2] = X[0:2]@w
    #print(X,w,x)
    sum_sin = np.sin(X[2])@w
    sum_cos = np.cos(X[2])@w
    x[2] = np.arctan2(sum_sin, sum_cos)
    return x

def hx(x):
    y = np.zeros((2,x.shape[1]))
    y[0] = x[0]
    y[1] = x[1]
    return y

def postprocess_data(x, lat0,lon0,alt0):
    
    N = len(x)
    x_enu = x[:,0,0]
    y_enu = x[:,1,0]
    z_enu = np.zeros_like(x_enu)
    yaw_enu = x[:,2,0]
    pitch_enu = np.zeros_like(x_enu)
    roll_enu = np.zeros_like(x_enu)

    lat, lon, alt = pm.enu2geodetic(x_enu, y_enu, z_enu, lat0, lon0, alt0)
    lat_lon_alt = np.vstack((lat,lon,alt)).T.reshape((N,3,1))
    
    lat0_rad = (np.pi/180)*lat0
    lon0_rad = (np.pi/180)*lon0
    R0_ecef_enu = np.array([[-np.sin(lon0_rad), -np.sin(lat0_rad)*np.cos(lon0_rad), np.cos(lat0_rad)*np.cos(lon0_rad)],
                            [ np.cos(lon0_rad), -np.sin(lat0_rad)*np.sin(lon0_rad), np.cos(lat0_rad)*np.sin(lon0_rad)],
                            [ 0,                 np.cos(lat0_rad),                  np.sin(lat0_rad)]])
    
    x_ecef, y_ecef, z_ecef = pm.enu2ecef(x_enu, y_enu, z_enu, lat0, lon0, alt0)
    X_ecef_body = np.vstack((x_ecef,y_ecef,z_ecef)).T.reshape((N,3,1))
    RT_ecef_body = np.zeros(((N,4,4)))
    for n in range(N):
        R_enu_body = Rot.from_euler('zyx', [yaw_enu[n],pitch_enu[n],roll_enu[n]]).as_matrix()
        R_ecef_body = R0_ecef_enu@R_enu_body
        RT_ecef_body[n] = np.vstack((np.hstack((R_ecef_body, X_ecef_body[n])), np.array([[0, 0, 0, 1]])))
        
    return RT_ecef_body, lat_lon_alt

def write_data_to_json_file(t_sync, RT_ecef_body, file_path):
    N = len(t_sync)
    data = {str(n): {'time': t_sync[n], 'RT_ECEF_body': RT_ecef_body[n].tolist(), 'version': 0.1} for n in range(N)}
    with open(file_path, 'w') as f:
        json.dump(data, f)
    return     