import numpy as np
from numpy.linalg import cholesky, qr, solve
from scipy.linalg import cho_factor, cho_solve, qr_update
import cholesky_updates as chol

class UKF:
    
    def __init__(self, implem='std', alpha=0.1, beta=2, kappa=0, deltaT=1/15):
        
        self.F = np.eye(10)
        Q = np.zeros((10, 10))
        
        sigma_ax = 2
        sigma_ay = 2
        sigma_aw = 2
        sigma_ah = 2
        sigma_ad = 0.03
        dsp_a = deltaT*np.array([sigma_ax, sigma_ay, sigma_aw, sigma_ah, sigma_ad])**2

        for i in range(5):
            self.F[i, 5 + i] = deltaT

            Q[i, i] = dsp_a[i]*deltaT**3/3
            Q[i, 5 + i] = dsp_a[i]*deltaT**2/2
            Q[5 + i, 5 + i] = dsp_a[i]*deltaT
            Q[5 + i, i] = dsp_a[i]*deltaT**2/2

        self.H = np.zeros((5,10))
        self.H[0:5,0:5] = np.eye(5)
        R = 6.25e-4*np.eye(5)
        R[4,4] = 1e-4
    
        (self.w, self.Wc, self.eta) = self.calc_sigma_points_weights(10, alpha, beta, kappa)
        
        if implem == 'srukf':
            self.Sq_l = cholesky(Q)
            self.Sr_l = cholesky(R)
        else:
            self.Q = Q
            self.Q_dmin = Q.copy()
            
            self.R = R
            self.R_dmin = R.copy()
            
    # initialize state and covariance        
    def initialize(self, y_meas, with_distance = False):
        
        x0 = np.zeros((10,1))
        x0[0:5, :] = y_meas 
                      
        Px0 = np.eye(10)
        Px0[0:4,0:4] = 2.5e-3*Px0[0:4,0:4]
        Px0[4,4] = 2e-3*Px0[4,4]
        Px0[5:9,5:9] = 0.1*Px0[5:9,5:9]
        Px0[9,9] = 0.1*Px0[9,9]
        
        if with_distance == True:
            
            dmin = 10/150
            dmax = 50/150
            cmax_dmin = 1
            cmin_dmax = 0.01
            a = (cmin_dmax - cmax_dmin) / (dmax - dmin)
            b = cmax_dmin - a * dmin
            
            d = min(max(dmin, y_meas[4]), dmax)
            c = a*d + b
            
            #Px0[0:4,0:4] *= c
            #Px0[5:9,5:9] *= c
            #Px0[4,4] /= c
            #Px0[9,9] /= c
            
                 
        return x0, Px0
    
    
    # covariances update with distance
    def update_covariance_with_distance(self, cov, d):
            
        dmin = 10/150
        dmax = 50/150
        cmax_dmin = 1
        cmin_dmax = 0.01
        a = (cmin_dmax - cmax_dmin) / (dmax - dmin)
        b = cmax_dmin - a * dmin
        
        d = min(max(dmin, d), dmax)
        c = a*d + b
        
        dmin_R = 10/150
        dmax_R = 50/150
        cmin_dmin_R = 1
        cmax_dmax_R = 100
        a_R = (cmax_dmax_R - cmin_dmin_R) / (dmax_R - dmin_R)
        b_R = cmin_dmin_R - a_R * dmin_R
        
        d_R = min(max(dmin_R, d), dmax_R)
        c_R = a_R*d_R + b_R
               
        if cov == 'Q':
            for i in range(4):
                self.Q[i, i] = c * self.Q_dmin[i, i]
                self.Q[i, 5 + i] = c * self.Q_dmin[i, 5 + i]
                self.Q[5 + i, 5 + i] = c * self.Q_dmin[5 + i, 5 + i]
                self.Q[5 + i, i] = c * self.Q_dmin[5 + i, i]
                
        if cov == 'R':
            #self.R[0:4,0:4] = c * self.R_dmin[0:4,0:4]
            self.R[4,4] = c_R * self.R_dmin[4,4]
        
    # computations of the sigma points weights and spread
    def calc_sigma_points_weights(self, n, alpha=0.1, beta=2, kappa=0): 
    
        lambda_ = alpha**2*(n + kappa) - n
        w = np.zeros((2*n + 1, 1))
        wc = np.zeros((2*n + 1, 1))
        w[0] = lambda_/(n + lambda_)
        wc[0] = w[0] + (1 - alpha**2 + beta)
        w[1:] = wc[1:] = 1/(2*(n + lambda_))
        eta = np.sqrt(n + lambda_)
        Wc = np.diagflat(wc)
    
        return w, Wc, eta

    # generate the sigma points matrix
    def generate_sigma_points(self, x_mean, Sx_l):
  
        X = np.hstack((x_mean, x_mean + self.eta*Sx_l, x_mean - self.eta*Sx_l))
    
        return X

    def process(self, X, V):
    
        X = self.F@X + V

        return X
    
    def measure(self, X, E):
    
        Y = self.H@X + E
    
        return Y

    ## standard UKF
    
    def time_update_ukf(self, x, Px):
    
        # sigma points generation
        Sx_l = cholesky(Px)
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through process
        Xx = self.process(Xx, 0)
        # compute predicted mean and covariance
        x = Xx@self.w
        Px = (Xx-x)@self.Wc@(Xx-x).T + self.Q
    
        return x, Px


    def measurement_update_ukf(self, x, Px, y_meas):
    
        # sigma points generation
        Sx_l = cholesky(Px)
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through measurement
        Y = self.measure(Xx, 0)
        y = Y@self.w
        Py = (Y-y)@self.Wc@(Y-y).T + self.R 
        Pxy = (Xx-x)@self.Wc@(Y-y).T
        # K = Pxy@np.linalg.inv(Py)
        Sy_h, low = cho_factor(Py, check_finite=False)
        K = cho_solve((Sy_h, low), Pxy.T).T
        x +=  K@(y_meas - y)
        Px = Px - K@Py@K.T
        #Px = (Px + Px.T)/2
    
        return x, Px
    

    # one step of the UKF
    def one_step_ukf(self, x, Px, y_meas):

        # TIME UPDATE (PREDICTION)
        x, Px = self.time_update_ukf(x, Px)

        # MEASUREMENT UPDATE
        x, Px = self.measurement_update_ukf(x, Px, y_meas)
    
        return x, Px

    
    ## Square Root UKF

    def time_update_srukf(self, x, Sx_l):
    
        # sigma points generation
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through process
        Xx = self.process(Xx, 0)
        # compute predicted mean and covariance square root
        x = Xx@self.w
    
        if self.Wc[0,0] < 0:
            Sx_l = qr(np.hstack(((Xx[:,1:]-x)@np.sqrt(self.Wc[1:,1:]), self.Sq_l)).T, mode = 'r').T
            chol.downdate(Sx_l, np.sqrt(-self.Wc[0,0])*(Xx[:,0:1]-x))
        else:
            Sx_l = qr(np.hstack(((Xx-x)@np.sqrt(self.Wc), self.Sq_l)).T, mode = 'r').T
    
        return x, Sx_l

    def measurement_update_srukf(self, x, Sx_l, y_meas):
    
        # sigma points generationtest
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through measurement
        Y = self.measure(Xx, 0)
        # compute corrected mean and covariance square root
        y = Y@self.w
        if self.Wc[0,0] < 0:
            Sy_l = qr(np.hstack(((Y[:,1:]-y)@np.sqrt(self.Wc[1:,1:]), self.Sr_l)).T, mode = 'r').T
            chol.downdate(Sy_l, np.sqrt(-self.Wc[0,0])*(Y[:,0:1]-y))
        else:
            Sy_l = qr(np.hstack(((Y-y)@np.sqrt(self.Wc), self.Sr_l)).T, mode = 'r').T
   
        Pxy = (Xx-x)@self.Wc@(Y-y).T
        K = cho_solve((Sy_l, True), Pxy.T).T
        x += K@(y_meas - y)
        Dc = K@Sy_l  #/!\ numerical issue in cholesky downdates with this multipiclation order
                    #/!\ but OK if downdates replaced by 'Sx_l = cholesky(Sx_l@Sx_l.T - Dc@Dc.T)'
        # for i in range(Dc.shape[1]):
        #     chol.downdate(Sx_l, Dc[:,i])
        DcT = Sy_l.T@K.T  # to avoid numerical issue (by reversing multiplication order)
        for i in range(DcT.shape[0]):
            chol.downdate(Sx_l, DcT[i,:])
        #Sx_l = cholesky(Sx_l@Sx_l.T - Dc@Dc.T)

        return x, Sx_l

    def one_step_srukf(self, x, Sx_l, y_meas):

        # TIME UPDATE (PREDICTION)
        x, Sx_l = self.time_update_srukf(x, Sx_l)
        # MEASUREMENT UPDATE
        x, Sx_l = self.measurement_update_srukf(x, Sx_l, y_meas)
    
        return x, Sx_l



class UKF_gen:
    
    def __init__(self, nx, ny, fx, hx, deltaT=1/15, implem='std', alpha=0.001, beta=2., kappa = 0., mean_x = None, subtract_x = None, add_x = None, mean_y = None, subtract_y = None):
        
        self.fx = fx
        self.hx = hx
        self.deltaT = deltaT
        
        Q = np.eye(nx)
        R = np.eye(ny)
        
        self.K = np.zeros((nx, ny))

        (self.w, self.Wc, self.eta) = self.calc_sigma_points_weights(nx, alpha, beta, kappa)
        
        if implem == 'srukf':
            self.Sq_l = cholesky(Q)
            self.Sr_l = cholesky(R)
        else:
            self.Q = Q       
            self.R = R
                 
        if mean_x is None:
            self.mean_x = np.dot
        else:
            self.mean_x = mean_x
         
        if subtract_x is None:
            self.subtract_x = np.subtract
        else:
            self.subtract_x = subtract_x
                 
        if add_x is None:
            self.add_x = np.add
        else:
            self.add_x = add_x     
            
        if mean_y is None:
            self.mean_y = np.dot
        else:
            self.mean_y = mean_y
           
        if subtract_y is None:
            self.subtract_y = np.subtract
        else:
            self.subtract_y = subtract_y
            
        
        
    # computations of the sigma points weights and spread
    def calc_sigma_points_weights(self, n, alpha=0.1, beta=2, kappa=0): 
        
        lambda_ = alpha**2*(n + kappa) - n
        w = np.zeros((2*n + 1, 1))
        wc = np.zeros((2*n + 1, 1))
        w[0] = lambda_/(n + lambda_)
        wc[0] = w[0] + (1 - alpha**2 + beta)
        w[1:] = wc[1:] = 1/(2*(n + lambda_))
        eta = np.sqrt(n + lambda_)
        Wc = np.diagflat(wc)
    
        return w, Wc, eta

    # generate the sigma points matrix
    def generate_sigma_points(self, x_mean, Sx_l):
  
        X = np.hstack((x_mean, self.add_x(x_mean, self.eta*Sx_l), self.subtract_x(x_mean, self.eta*Sx_l)))
    
        return X

    def process(self, X, u):
    
        X = self.fx(X, u, self.deltaT)

        return X
    
    def measure(self, X):
    
        Y = self.hx(X)
    
        return Y

    ## standard UKF
    
    def time_update_ukf(self, x, Px, u = None):
    
        # sigma points generation
        Sx_l = cholesky(Px)
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through process
        Xx = self.process(Xx, u)
        # compute predicted mean and covariance
        x = self.mean_x(Xx, self.w)
        Xx_minus_x = self.subtract_x(Xx, x)
        Px = Xx_minus_x@self.Wc@Xx_minus_x.T + self.Q
    
        return x, Px


    def measurement_update_ukf(self, x, Px, y_meas):
    
        # sigma points generation
        Sx_l = cholesky(Px)
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through measurement
        Y = self.measure(Xx)
        y = self.mean_y(Y, self.w)
        Y_minus_y = self.subtract_y(Y, y)
        Py = Y_minus_y@self.Wc@Y_minus_y.T + self.R                    
        Pxy = self.subtract_x(Xx, x)@self.Wc@Y_minus_y.T
        Sy_h, low = cho_factor(Py, check_finite=False)
        self.K = cho_solve((Sy_h, low), Pxy.T).T
        #self.K = solve(Py.T,Pxy.T).T
        #self.K = Pxy@np.linalg.inv(Py)
        x = self.add_x(x, self.K@self.subtract_y(y_meas, y)) 
        Px += - self.K@Py@self.K.T
    
        return x, Px
    

    # one step of the UKF
    def one_step_ukf(self, x, Px, y_meas, u = None):

        # TIME UPDATE (PREDICTION)
        x, Px = self.time_update_ukf(x, Px, u)

        # MEASUREMENT UPDATE
        x, Px = self.measurement_update_ukf(x, Px, y_meas)
    
        return x, Px

    
    ## Square Root UKF

    def time_update_srukf(self, x, Sx_l, u = None):
    
        # sigma points generation
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through process
        Xx = self.process(Xx, u)
        # compute predicted mean and covariance square root
        x = self.mean_x(Xx, self.w)
    
        if self.Wc[0,0] < 0:
            Sx_l = qr(np.hstack((self.subtract_x(Xx[:,1:], x)@np.sqrt(self.Wc[1:,1:]), self.Sq_l)).T, mode = 'r').T
            chol.downdate(Sx_l, np.sqrt(-self.Wc[0,0])*self.subtract_x(Xx[:,0:1], x))
        else:
            Sx_l = qr(np.hstack((self.subtract_x(Xx, x)@np.sqrt(self.Wc), self.Sq_l)).T, mode = 'r').T
    
        return x, Sx_l

    def measurement_update_srukf(self, x, Sx_l, y_meas):
    
        # sigma points generationtest
        Xx = self.generate_sigma_points(x, Sx_l)
        # sigma points propagation through measurement
        Y = self.measure(Xx)
        # compute corrected mean and covariance square root
        y = self.mean_y(Y, self.w)
        if self.Wc[0,0] < 0:
            Sy_l = qr(np.hstack(((self.subtract_y(Y[:,1:], y))@np.sqrt(self.Wc[1:,1:]), self.Sr_l)).T, mode = 'r').T
            chol.downdate(Sy_l, np.sqrt(-self.Wc[0,0])*(self.subtract_y(Y[:,0:1], y)))
        else:
            Sy_l = qr(np.hstack(((self.subtract_y(Y, y))@np.sqrt(self.Wc), self.Sr_l)).T, mode = 'r').T
   
        Pxy = self.subtract_x(Xx, x)@self.Wc@self.subtract_y(Y, y).T
        self.K = cho_solve((Sy_l, True), Pxy.T).T
        #self.K = Pxy@np.linalg.inv(Sy_l)@np.linalg.inv(Sy_l.T)
        x = self.add_x(x, self.K@self.subtract_y(y_meas, y))
        #Dc = self.K@Sy_l  /!\ numerical issue in cholesky downdates with this multipiclation order
        #                  /!\ but OK if downdates replaced by 'Sx_l = cholesky(Sx_l@Sx_l.T - Dc@Dc.T)'
        #for i in range(Dc.shape[1]):
        #    chol.downdate(Sx_l, Dc[:,i])
        DcT = Sy_l.T@self.K.T  # to avoid numerical issue (by reversing multiplication order)
        for i in range(DcT.shape[0]):
            chol.downdate(Sx_l, DcT[i,:])
        #Sx_l = cholesky(Sx_l@Sx_l.T - DcT.T@DcT)

        return x, Sx_l

    def one_step_srukf(self, x, Sx_l, y_meas, u = None):

        # TIME UPDATE (PREDICTION)
        x, Sx_l = self.time_update_srukf(x, Sx_l, u)
        # MEASUREMENT UPDATE
        x, Sx_l = self.measurement_update_srukf(x, Sx_l, y_meas)
    
        return x, Sx_l